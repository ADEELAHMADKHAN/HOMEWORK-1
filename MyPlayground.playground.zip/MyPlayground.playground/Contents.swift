import UIKit


func Sum(_ nums: [Int], _ target: Int) -> [Int] {
    var toggle = false
    for i in 0..<nums.count {
        for j in i+1..<nums.count {
        if toggle == false {
        if(nums[i]+nums[j]==target){
        toggle = true
        arr.insert(i, at: 0)
        arr.insert(j, at: 1)
        break
        }
    }
}
        
}
    return arr
}
var arr:[Int] = []
var nums1 = [2, 7, 11, 15]
var target2 = 9
let result = Sum(nums1, target2)
print(result)

