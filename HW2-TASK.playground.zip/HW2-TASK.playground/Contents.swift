import UIKit
var prefix = ["flower","flow","flight"]
var arr = [Int]()
let a=prefix.count
let str1 = prefix[0]
for ik in 1...prefix.count-1
{
    var strcount = 0
    for ij in str1
    {
        for ig in prefix[ik] {
        
        var str2 = prefix[ik]
        
        if (ij==ig)
        {
            strcount += 1
    }}}
arr.append(strcount)}

let ax = arr.min()
var cx = 0
for ih in str1
{
    if ax!==cx
    { break }
    cx += 1
    print(ih)
}

